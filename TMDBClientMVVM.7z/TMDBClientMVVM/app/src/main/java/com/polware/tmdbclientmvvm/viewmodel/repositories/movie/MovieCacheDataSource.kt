package com.polware.tmdbclientmvvm.viewmodel.repositories.movie

import com.polware.tmdbclientmvvm.data.models.Movie

interface MovieCacheDataSource {

    suspend fun getMoviesFromCache(): List<Movie>

    suspend fun saveMoviesToCache(movies: List<Movie>)

}