package com.polware.tmdbclientmvvm.view.depinjection

import com.polware.tmdbclientmvvm.view.depinjection.artist.ArtistSubComponent
import com.polware.tmdbclientmvvm.view.depinjection.movie.MovieSubComponent
import com.polware.tmdbclientmvvm.view.depinjection.tvshow.TvShowSubComponent

interface Injector {

    fun createMovieSubComponent(): MovieSubComponent
    fun createTvShowSubComponent(): TvShowSubComponent
    fun createArtistSubComponent(): ArtistSubComponent

}