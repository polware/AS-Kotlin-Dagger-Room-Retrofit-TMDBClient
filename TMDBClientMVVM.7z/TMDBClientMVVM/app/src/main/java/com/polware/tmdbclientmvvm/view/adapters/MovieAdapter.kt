package com.polware.tmdbclientmvvm.view.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.polware.tmdbclientmvvm.R
import com.polware.tmdbclientmvvm.data.models.Movie
import com.polware.tmdbclientmvvm.databinding.ListItemBinding

class MovieAdapter(): RecyclerView.Adapter<MovieViewHolder>() {
    private val movieList = ArrayList<Movie>()

    fun setList(movies: List<Movie>){
         movieList.clear()
         movieList.addAll(movies)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val bindingAdapter: ListItemBinding = DataBindingUtil.inflate(layoutInflater,
            R.layout.list_item, parent, false)
        return MovieViewHolder(bindingAdapter)
    }

    override fun getItemCount(): Int {
        return movieList.size
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
       holder.bind(movieList[position])
    }
}

class MovieViewHolder(val binding: ListItemBinding):
    RecyclerView.ViewHolder(binding.root){

   fun bind(movie: Movie){
        binding.titleTextView.text = movie.title
        binding.descriptionTextView.text = movie.overview
        val posterURL = "https://image.tmdb.org/t/p/w500"+movie.posterPath
        Glide.with(binding.imageView.context)
            .load(posterURL)
            .into(binding.imageView)
   }

}