package com.polware.tmdbclientmvvm.viewmodel.repositories.movie

import com.polware.tmdbclientmvvm.data.models.Movie

interface MovieRepository {

    suspend fun getMovies(): List<Movie>?
    suspend fun updateMovies(): List<Movie>?

}