package com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow

import com.polware.tmdbclientmvvm.data.api.TMDBService
import com.polware.tmdbclientmvvm.data.models.TvShowList
import retrofit2.Response

class TvShowRemoteDataSourceImpl(private val tmdbService: TMDBService,
                                 private val apiKey:String): TvShowRemoteDatasource {

    override suspend fun getTvShows():
            Response<TvShowList> = tmdbService.getPopularTvShows(apiKey)

}

