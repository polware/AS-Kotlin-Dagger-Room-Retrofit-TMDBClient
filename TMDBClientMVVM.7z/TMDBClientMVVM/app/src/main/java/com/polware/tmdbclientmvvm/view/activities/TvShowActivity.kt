package com.polware.tmdbclientmvvm.view.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.polware.tmdbclientmvvm.R
import com.polware.tmdbclientmvvm.databinding.ActivityTvShowBinding
import com.polware.tmdbclientmvvm.view.adapters.TvShowAdapter
import com.polware.tmdbclientmvvm.view.depinjection.Injector
import com.polware.tmdbclientmvvm.viewmodel.TvShowViewModel
import com.polware.tmdbclientmvvm.viewmodel.TvShowViewModelFactory
import javax.inject.Inject

class TvShowActivity : AppCompatActivity() {
    @Inject
    lateinit var factory: TvShowViewModelFactory
    private lateinit var tvShowViewModel: TvShowViewModel
    private lateinit var adapter: TvShowAdapter
    private lateinit var bindingTvShow: ActivityTvShowBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingTvShow = DataBindingUtil.setContentView(this, R.layout.activity_tv_show)
        supportActionBar?.title = "Popular TV Shows"
        (application as Injector).createTvShowSubComponent().inject(this)

        tvShowViewModel= ViewModelProvider(this,factory)
            .get(TvShowViewModel::class.java)
        initRecyclerView()
    }

    private fun initRecyclerView(){
        bindingTvShow.recyclerViewTvShow.layoutManager = LinearLayoutManager(this)
        adapter = TvShowAdapter()
        bindingTvShow.recyclerViewTvShow.adapter = adapter
        displayPopularTvShows()
    }

    private fun displayPopularTvShows(){
        bindingTvShow.progressBarTvShow.visibility = View.VISIBLE
        val responseLiveData = tvShowViewModel.getTvShows()
        responseLiveData.observe(this, Observer {
            if(it!=null){
                adapter.setList(it)
                adapter.notifyDataSetChanged()
                bindingTvShow.progressBarTvShow.visibility = View.GONE
            }else{
                bindingTvShow.progressBarTvShow.visibility = View.GONE
                Toast.makeText(applicationContext,"No data available", Toast.LENGTH_LONG).show()
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater : MenuInflater = menuInflater
        inflater.inflate(R.menu.update,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId){
            R.id.action_update -> {
                updateTvShows()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun updateTvShows(){
        bindingTvShow.progressBarTvShow.visibility = View.VISIBLE
        val response = tvShowViewModel.updateTvShows()
        response.observe(this, Observer {
            if(it!=null){
                adapter.setList(it)
                adapter.notifyDataSetChanged()
                bindingTvShow.progressBarTvShow.visibility = View.GONE
            }else{
                bindingTvShow.progressBarTvShow.visibility = View.GONE
            }
        })
    }

}