package com.polware.tmdbclientmvvm.view

import android.app.Application
import com.polware.tmdbclientmvvm.BuildConfig
import com.polware.tmdbclientmvvm.view.depinjection.*
import com.polware.tmdbclientmvvm.view.depinjection.artist.ArtistSubComponent
import com.polware.tmdbclientmvvm.view.depinjection.components.*
import com.polware.tmdbclientmvvm.view.depinjection.movie.MovieSubComponent
import com.polware.tmdbclientmvvm.view.depinjection.tvshow.TvShowSubComponent

/**
 * Development Steps:
 * 1) Data: Models, Api, Database
 * 2) ViewModel: Repositories Artist-Movie-TvShow, UseCases || RepositoriesImplement,
 *               remote-local-cache DataSources, DataSources Implements
 * 3) View: Xml for MainActivity, Movie-Artist-TvShows Activities
 * 4) ViewModel: Artist-Movie-TvShows ViewModels, Artist-Movie-TvShows Factories
 * 5) D.Injection: Network-Database-RemoteData-LocalData-CacheData-Repository-UseCases-App modules
 * 6) D. Injection: AppComponent || Artist-Movie-TvShow (modules, scopes, subComponents)
 * 7) D. Injection: Injector, Application Class
 * 8) View: Adapters (3), Movie-Artist-TvShows activities
 */

class App: Application(), Injector {
    private lateinit var appComponent: AppComponent

    override fun onCreate() {
        super.onCreate()
        appComponent = DaggerAppComponent.builder()
            .appModule(AppModule(applicationContext))
            .networkModule(NetworkModule(BuildConfig.BASE_URL))
            .remoteDataModule(RemoteDataModule(BuildConfig.API_KEY))
            .build()
    }

    override fun createMovieSubComponent(): MovieSubComponent {
        return appComponent.movieSubComponent().create()
    }

    override fun createTvShowSubComponent(): TvShowSubComponent {
        return appComponent.tvShowSubComponent().create()
    }

    override fun createArtistSubComponent(): ArtistSubComponent {
        return appComponent.artistSubComponent().create()
    }

}