package com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow

import com.polware.tmdbclientmvvm.data.models.TvShow

interface TvShowLocalDataSource {

  suspend fun getTvShowsFromDB(): List<TvShow>
  suspend fun saveTvShowsToDB(tvShows: List<TvShow>)
  suspend fun clearAll()

}