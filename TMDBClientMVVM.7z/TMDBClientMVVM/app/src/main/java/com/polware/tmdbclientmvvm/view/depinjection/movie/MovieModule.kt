package com.polware.tmdbclientmvvm.view.depinjection.movie

import com.polware.tmdbclientmvvm.viewmodel.MovieViewModelFactory
import com.polware.tmdbclientmvvm.viewmodel.usecases.GetMoviesUseCase
import com.polware.tmdbclientmvvm.viewmodel.usecases.UpdateMoviesUseCase
import dagger.Module
import dagger.Provides

@Module
class MovieModule {
    @MovieScope
    @Provides
    fun provideMovieViewModelFactory(
        getMoviesUseCase: GetMoviesUseCase,
        updateMoviesUsecase: UpdateMoviesUseCase
    ): MovieViewModelFactory {

        return MovieViewModelFactory(getMoviesUseCase, updateMoviesUsecase)
    }

}