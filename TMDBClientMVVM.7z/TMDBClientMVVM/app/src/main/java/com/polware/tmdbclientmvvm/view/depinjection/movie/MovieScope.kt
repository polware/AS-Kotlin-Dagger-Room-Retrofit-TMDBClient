package com.polware.tmdbclientmvvm.view.depinjection.movie

import javax.inject.Scope

// Scope for MovieViewModel Factory dependency
@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class MovieScope


