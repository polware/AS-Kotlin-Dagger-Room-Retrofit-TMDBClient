package com.polware.tmdbclientmvvm.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.polware.tmdbclientmvvm.viewmodel.usecases.GetMoviesUseCase
import com.polware.tmdbclientmvvm.viewmodel.usecases.UpdateMoviesUseCase

class MovieViewModel(
    private val getMoviesUseCase: GetMoviesUseCase,
    private val updateMoviesUseCase: UpdateMoviesUseCase): ViewModel() {

    fun getMovies() = liveData {
        val movieList = getMoviesUseCase.execute()
        emit(movieList)
    }

    fun updateMovies() = liveData {
        val movieList = updateMoviesUseCase.execute()
        emit(movieList)
    }

}