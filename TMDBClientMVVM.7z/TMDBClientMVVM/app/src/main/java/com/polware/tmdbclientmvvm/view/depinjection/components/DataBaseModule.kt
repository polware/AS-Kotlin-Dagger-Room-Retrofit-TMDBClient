package com.polware.tmdbclientmvvm.view.depinjection.components

import android.content.Context
import androidx.room.Room
import com.polware.tmdbclientmvvm.data.database.ArtistDao
import com.polware.tmdbclientmvvm.data.database.MovieDao
import com.polware.tmdbclientmvvm.data.database.TMDBDatabase
import com.polware.tmdbclientmvvm.data.database.TvShowDao
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class DataBaseModule {

    @Singleton
    @Provides
    fun provideMovieDataBase(context: Context): TMDBDatabase {
        return Room.databaseBuilder(context, TMDBDatabase::class.java,"tmdbclient")
            .build()
    }

    @Singleton
    @Provides
    fun provideMovieDao(tmdbDatabase: TMDBDatabase): MovieDao {
        return tmdbDatabase.movieDao()
    }

    @Singleton
    @Provides
    fun provideTvDao(tmdbDatabase: TMDBDatabase): TvShowDao {
        return tmdbDatabase.tvShowDao()
    }

    @Singleton
    @Provides
    fun provideArtistDao(tmdbDatabase: TMDBDatabase): ArtistDao {
        return tmdbDatabase.artistDao()
    }

}