package com.polware.tmdbclientmvvm.viewmodel.usecases

import com.polware.tmdbclientmvvm.data.models.Artist
import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistRepository

class GetArtistsUseCase(private val artistRepository: ArtistRepository) {

    suspend fun execute(): List<Artist>? = artistRepository.getArtists()

}