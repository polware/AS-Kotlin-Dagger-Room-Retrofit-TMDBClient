package com.polware.tmdbclientmvvm.viewmodel.usecases

import com.polware.tmdbclientmvvm.data.models.TvShow
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowRepository

class UpdateTvShowsUseCase(private val tvShowRepository: TvShowRepository) {

    suspend fun execute(): List<TvShow>? = tvShowRepository.updateTvShows()

}