package com.polware.tmdbclientmvvm.view.depinjection.tvshow

import com.polware.tmdbclientmvvm.viewmodel.TvShowViewModelFactory
import com.polware.tmdbclientmvvm.viewmodel.usecases.GetTvShowsUseCase
import com.polware.tmdbclientmvvm.viewmodel.usecases.UpdateTvShowsUseCase
import dagger.Module
import dagger.Provides

@Module
class TvShowModule {
    @TvShowScope
    @Provides
    fun provideTvShowViewModelFactory(
        getTvShowsUseCase: GetTvShowsUseCase,
        updateTvShowsUseCase: UpdateTvShowsUseCase
    ): TvShowViewModelFactory {

        return TvShowViewModelFactory(getTvShowsUseCase, updateTvShowsUseCase)
    }

}