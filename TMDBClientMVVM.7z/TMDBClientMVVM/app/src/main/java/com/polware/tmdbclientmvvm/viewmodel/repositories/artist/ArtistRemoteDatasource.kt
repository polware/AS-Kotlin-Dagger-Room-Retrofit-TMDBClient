package com.polware.tmdbclientmvvm.viewmodel.repositories.artist

import com.polware.tmdbclientmvvm.data.models.ArtistList
import retrofit2.Response

interface ArtistRemoteDatasource {

   suspend fun getArtists(): Response<ArtistList>

}