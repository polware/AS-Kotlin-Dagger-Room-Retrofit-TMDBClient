package com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow

import com.polware.tmdbclientmvvm.data.models.TvShowList
import retrofit2.Response

interface TvShowRemoteDatasource {

   suspend fun getTvShows(): Response<TvShowList>

}