package com.polware.tmdbclientmvvm.viewmodel.repositories.artist

import com.polware.tmdbclientmvvm.data.models.Artist

interface ArtistLocalDataSource {

  suspend fun getArtistsFromDB(): List<Artist>
  suspend fun saveArtistsToDB(artists: List<Artist>)
  suspend fun clearAll()

}