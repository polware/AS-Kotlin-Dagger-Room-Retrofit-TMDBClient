package com.polware.tmdbclientmvvm.viewmodel.repositories.artist

import com.polware.tmdbclientmvvm.data.api.TMDBService
import com.polware.tmdbclientmvvm.data.models.ArtistList
import retrofit2.Response

class ArtistRemoteDataSourceImpl(private val tmdbService: TMDBService,
                                 private val apiKey:String): ArtistRemoteDatasource {

    override suspend fun getArtists()
            : Response<ArtistList> = tmdbService.getPopularArtists(apiKey)

}

