package com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow

import com.polware.tmdbclientmvvm.data.models.TvShow

interface TvShowCacheDataSource {

    suspend fun getTvShowsFromCache(): List<TvShow>
    suspend fun saveTvShowsToCache(tvShows: List<TvShow>)

}