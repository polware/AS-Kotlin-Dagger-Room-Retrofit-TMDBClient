package com.polware.tmdbclientmvvm.view.depinjection.components

import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistCacheDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistCacheDataSourceImpl
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieCacheDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieCacheDataSourceImpl
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowCacheDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowCacheDataSourceImpl
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

// This module loads the data stored in the cache
@Module
class CacheDataModule {

    @Singleton
    @Provides
    fun provideMovieCacheDataSource(): MovieCacheDataSource {
        return MovieCacheDataSourceImpl()
    }

    @Singleton
    @Provides
    fun provideTvShowCacheDataSource(): TvShowCacheDataSource {
        return TvShowCacheDataSourceImpl()
    }

    @Singleton
    @Provides
    fun provideArtistCacheDataSource(): ArtistCacheDataSource {
        return ArtistCacheDataSourceImpl()
    }

}