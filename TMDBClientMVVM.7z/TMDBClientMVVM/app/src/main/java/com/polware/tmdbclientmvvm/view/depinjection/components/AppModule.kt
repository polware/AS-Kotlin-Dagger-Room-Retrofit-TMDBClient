package com.polware.tmdbclientmvvm.view.depinjection.components

import android.content.Context
import com.polware.tmdbclientmvvm.view.depinjection.artist.ArtistSubComponent
import com.polware.tmdbclientmvvm.view.depinjection.movie.MovieSubComponent
import com.polware.tmdbclientmvvm.view.depinjection.tvshow.TvShowSubComponent
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

// This module provides the application context dependency
@Module(subcomponents = [MovieSubComponent::class, TvShowSubComponent::class, ArtistSubComponent::class])
class AppModule(private val context: Context) {

    @Singleton
    @Provides
    fun provideApplicationContext(): Context{
        return context.applicationContext
    }

}