package com.polware.tmdbclientmvvm.view.depinjection.tvshow

import javax.inject.Scope

// Scope for TvShowViewModel Factory dependency
@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class TvShowScope
