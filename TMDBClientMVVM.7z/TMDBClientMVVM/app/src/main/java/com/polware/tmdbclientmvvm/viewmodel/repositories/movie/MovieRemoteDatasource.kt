package com.polware.tmdbclientmvvm.viewmodel.repositories.movie

import com.polware.tmdbclientmvvm.data.models.MovieList
import retrofit2.Response

interface MovieRemoteDatasource {

    suspend fun getMovies(): Response<MovieList>

}