package com.polware.tmdbclientmvvm.view.depinjection.components

import com.polware.tmdbclientmvvm.data.api.TMDBService
import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistRemoteDataSourceImpl
import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistRemoteDatasource
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieRemoteDataSourceImpl
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieRemoteDatasource
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowRemoteDataSourceImpl
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowRemoteDatasource
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

// This module execute requests to the API service
@Module
class RemoteDataModule(private val apiKey: String) {

    @Singleton
    @Provides
    fun provideMovieRemoteDataSource(tmdbService: TMDBService): MovieRemoteDatasource {
        return MovieRemoteDataSourceImpl(tmdbService, apiKey)
    }

    @Singleton
    @Provides
    fun provideTvRemoteDataSource(tmdbService: TMDBService): TvShowRemoteDatasource {
        return TvShowRemoteDataSourceImpl(tmdbService, apiKey)
    }

    @Singleton
    @Provides
    fun provideArtistRemoteDataSource(tmdbService: TMDBService): ArtistRemoteDatasource {
        return ArtistRemoteDataSourceImpl(tmdbService, apiKey)
    }


}