package com.polware.tmdbclientmvvm.view.depinjection.artist

import javax.inject.Scope

// Scope for ArtistViewModel Factory dependency
@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class ArtistScope
