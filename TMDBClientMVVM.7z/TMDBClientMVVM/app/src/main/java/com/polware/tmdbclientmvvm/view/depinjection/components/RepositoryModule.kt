package com.polware.tmdbclientmvvm.view.depinjection.components

import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistCacheDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistLocalDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistRemoteDatasource
import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistRepositoryImpl
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieCacheDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieLocalDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieRemoteDatasource
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieRepositoryImpl
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowCacheDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowLocalDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowRemoteDatasource
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowRepositoryImpl
import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistRepository
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieRepository
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowRepository
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

// This module provides the data returned by repositories and DataSources
@Module
class RepositoryModule {

    @Provides
    @Singleton
    fun provideMovieRepository(
        movieRemoteDatasource: MovieRemoteDatasource,
        movieLocalDataSource: MovieLocalDataSource,
        movieCacheDataSource: MovieCacheDataSource
        ): MovieRepository {

        return MovieRepositoryImpl(movieRemoteDatasource, movieLocalDataSource, movieCacheDataSource)
    }

    @Provides
    @Singleton
    fun provideTvShowRepository(
        tvShowRemoteDatasource: TvShowRemoteDatasource,
        tvShowLocalDataSource: TvShowLocalDataSource,
        tvShowCacheDataSource: TvShowCacheDataSource
        ): TvShowRepository {

        return TvShowRepositoryImpl(tvShowRemoteDatasource, tvShowLocalDataSource, tvShowCacheDataSource)
    }

    @Provides
    @Singleton
    fun provideArtistRepository(
        artistRemoteDatasource: ArtistRemoteDatasource,
        artistLocalDataSource: ArtistLocalDataSource,
        artistCacheDataSource: ArtistCacheDataSource
        ): ArtistRepository {

        return ArtistRepositoryImpl(artistRemoteDatasource, artistLocalDataSource, artistCacheDataSource)
    }

}