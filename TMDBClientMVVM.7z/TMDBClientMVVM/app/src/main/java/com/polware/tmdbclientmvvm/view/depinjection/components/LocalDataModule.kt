package com.polware.tmdbclientmvvm.view.depinjection.components

import com.polware.tmdbclientmvvm.data.database.ArtistDao
import com.polware.tmdbclientmvvm.data.database.MovieDao
import com.polware.tmdbclientmvvm.data.database.TvShowDao
import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistLocalDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.artist.ArtistLocalDataSourceImpl
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieLocalDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieLocalDataSourceImpl
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowLocalDataSource
import com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow.TvShowLocalDataSourceImpl
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

// This module executes the CRUD operations on the Room database
@Module
class LocalDataModule {

    @Singleton
    @Provides
    fun provideMovieLocalDataSource(movieDao: MovieDao): MovieLocalDataSource {
        return MovieLocalDataSourceImpl(movieDao)
    }

    @Singleton
    @Provides
    fun provideTvShowLocalDataSource(tvShowDao: TvShowDao): TvShowLocalDataSource {
        return TvShowLocalDataSourceImpl(tvShowDao)
    }

    @Singleton
    @Provides
    fun provideArtistLocalDataSource(artistDao : ArtistDao): ArtistLocalDataSource {
        return ArtistLocalDataSourceImpl(artistDao)
    }

}