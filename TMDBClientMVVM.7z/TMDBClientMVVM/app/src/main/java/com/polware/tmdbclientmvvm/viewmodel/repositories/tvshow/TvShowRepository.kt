package com.polware.tmdbclientmvvm.viewmodel.repositories.tvshow

import com.polware.tmdbclientmvvm.data.models.TvShow

interface TvShowRepository {

    suspend fun getTvShows(): List<TvShow>?
    suspend fun updateTvShows(): List<TvShow>?

}