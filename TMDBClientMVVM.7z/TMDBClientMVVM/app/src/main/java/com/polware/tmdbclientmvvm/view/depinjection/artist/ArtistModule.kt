package com.polware.tmdbclientmvvm.view.depinjection.artist

import com.polware.tmdbclientmvvm.viewmodel.ArtistViewModelFactory
import com.polware.tmdbclientmvvm.viewmodel.usecases.GetArtistsUseCase
import com.polware.tmdbclientmvvm.viewmodel.usecases.UpdateArtistsUseCase
import dagger.Module
import dagger.Provides

@Module
class ArtistModule {
    @ArtistScope
    @Provides
    fun provideArtistViewModelFactory(getArtistsUseCase: GetArtistsUseCase,
        updateArtistsUseCase: UpdateArtistsUseCase): ArtistViewModelFactory {

        return ArtistViewModelFactory(getArtistsUseCase, updateArtistsUseCase)
    }

}