package com.polware.tmdbclientmvvm.view.depinjection.components

import com.polware.tmdbclientmvvm.view.depinjection.artist.ArtistSubComponent
import com.polware.tmdbclientmvvm.view.depinjection.movie.MovieSubComponent
import com.polware.tmdbclientmvvm.view.depinjection.tvshow.TvShowSubComponent
import dagger.Component
import javax.inject.Singleton

// Provides the list of all components(modules) and subcomponents
@Singleton
@Component(modules = [
    AppModule::class,
    NetworkModule::class,
    DataBaseModule::class,
    UseCasesModule::class,
    RepositoryModule::class,
    RemoteDataModule::class,
    LocalDataModule::class,
    CacheDataModule::class
    ])
interface AppComponent {

    fun movieSubComponent(): MovieSubComponent.Factory
    fun tvShowSubComponent(): TvShowSubComponent.Factory
    fun artistSubComponent(): ArtistSubComponent.Factory

}