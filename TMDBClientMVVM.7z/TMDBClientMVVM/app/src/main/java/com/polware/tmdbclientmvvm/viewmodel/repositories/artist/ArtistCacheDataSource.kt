package com.polware.tmdbclientmvvm.viewmodel.repositories.artist

import com.polware.tmdbclientmvvm.data.models.Artist

interface ArtistCacheDataSource {

    suspend fun getArtistsFromCache(): List<Artist>
    suspend fun saveArtistsToCache(artists: List<Artist>)

}