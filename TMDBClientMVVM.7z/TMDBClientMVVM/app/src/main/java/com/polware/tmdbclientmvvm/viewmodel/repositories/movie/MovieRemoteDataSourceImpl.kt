package com.polware.tmdbclientmvvm.viewmodel.repositories.movie

import com.polware.tmdbclientmvvm.data.api.TMDBService
import com.polware.tmdbclientmvvm.data.models.MovieList
import retrofit2.Response

class MovieRemoteDataSourceImpl(private val tmdbService: TMDBService,
                                private val apiKey:String): MovieRemoteDatasource {

    override suspend fun getMovies(): Response<MovieList> = tmdbService.getPopularMovies(apiKey)

}