package com.polware.tmdbclientmvvm.viewmodel.usecases

import com.polware.tmdbclientmvvm.data.models.Movie
import com.polware.tmdbclientmvvm.viewmodel.repositories.movie.MovieRepository

class UpdateMoviesUseCase(private val movieRepository: MovieRepository) {

    suspend fun execute(): List<Movie>? = movieRepository.updateMovies()

}